       IDENTIFICATION DIVISION.
       PROGRAM-ID. PROG191.

       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-INPUT-STR        PIC X(50) VALUE "A,B,C,191".
       01  WS-TOKEN1           PIC X(10).
       01  WS-TOKEN2           PIC X(10).
       01  WS-TOKEN3           PIC X(10).
       01  WS-TOKEN4           PIC X(10).

       01  WS-CHAR             PIC X VALUE "J".
       01  WS-ORD              PIC 9(4).
       01  WS-NEW-CHAR         PIC X.

       01  WS-NUM1             PIC 9(4) VALUE 18.
       01  WS-NUM2             PIC 9(4) VALUE 2.
       01  WS-RES              PIC S9(6).

       PROCEDURE DIVISION.
       MAIN-PARA.

           DISPLAY "Program 191 Started".

           * --- SPLIT USING UNSTRING ---
           UNSTRING WS-INPUT-STR
               DELIMITED BY ","
               INTO WS-TOKEN1 WS-TOKEN2 WS-TOKEN3 WS-TOKEN4
           END-UNSTRING.

           DISPLAY "Tokens:" WS-TOKEN1 WS-TOKEN2 WS-TOKEN3 WS-TOKEN4.

           * --- CHARACTER ARITHMETIC ---
           COMPUTE WS-ORD = FUNCTION ORD(WS-CHAR).
           COMPUTE WS-ORD = WS-ORD + 1.
           COMPUTE WS-NEW-CHAR = FUNCTION CHAR(WS-ORD).

           DISPLAY "Original Char: " WS-CHAR.
           DISPLAY "Next Char: " WS-NEW-CHAR.

           * --- INTRINSIC FUNCTIONS ---
           COMPUTE WS-RES = FUNCTION MAX(WS-NUM1, WS-NUM2).
           DISPLAY "Max Value: " WS-RES.

           COMPUTE WS-RES = FUNCTION MIN(WS-NUM1, WS-NUM2).
           DISPLAY "Min Value: " WS-RES.

           COMPUTE WS-RES = FUNCTION MOD(WS-NUM1, WS-NUM2).
           DISPLAY "Modulo: " WS-RES.

           * --- ARITHMETIC ---
           ADD WS-NUM1 TO WS-NUM2 GIVING WS-RES.
           DISPLAY "Add Result: " WS-RES.

           SUBTRACT WS-NUM1 FROM WS-NUM2 GIVING WS-RES.
           DISPLAY "Sub Result: " WS-RES.

           MULTIPLY WS-NUM1 BY WS-NUM2 GIVING WS-RES.
           DISPLAY "Mul Result: " WS-RES.

           DIVIDE WS-NUM2 BY WS-NUM1 GIVING WS-RES.
           DISPLAY "Div Result: " WS-RES.

           STOP RUN.
